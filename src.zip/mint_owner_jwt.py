import time
from jose import jwt

# --- EDIT THESE THREE ---
SECRET    = "super-long-very-random-secret-change-me-now"  # same as JWT_SECRET if you created a .env
TENANT_ID = "932b8a63-6cf3-4d0f-b157-6ba18e3931e2"
EMAIL     = "admin@gmail.com"                          # or whatever you used

# Algorithm
ALG = "HS256"

# Type for your owner admin
TYPE = ["PLATFORM_OWNER"]

now = int(time.time())
claims = {
    "sub": EMAIL,
    "tenant_id": TENANT_ID,
    "roles": TYPE,
    "iat": now,
    "exp": now + 60 * 60 * 24 * 7,  # 12h
}

token = jwt.encode(claims, SECRET, algorithm=ALG)
print(token)

# eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbkBnbWFpbC5jb20iLCJ0ZW5hbnRfaWQiOiI5MzJiOGE2My02Y2YzLTRkMGYtYjE1Ny02YmExOGUzOTMxZTIiLCJyb2xlcyI6WyJQTEFURk9STV9PV05FUiJdLCJpYXQiOjE3NTU2OTY4NjMsImV4cCI6MTc1NjMwMTY2M30.KxOK1ZmfHcjn8e0RlZy2IUm6kJYYds5NVbJYdIywVgA