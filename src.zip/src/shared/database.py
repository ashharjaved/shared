from __future__ import annotations
# add near the top, after settings/env are loaded but before app = FastAPI(...)

from contextlib import contextmanager
from typing import AsyncGenerator, Generator

from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker, DeclarativeBase
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from src.config import settings
    

class Base(DeclarativeBase):
    """Declarative base for ORM models."""
    pass
# ---------------------------------------------------------------------
# Single sources of truth (created once, reused)
# ---------------------------------------------------------------------
_async_engine: AsyncEngine | None = None
_async_session_factory: async_sessionmaker[AsyncSession] | None = None
_sync_session_factory: sessionmaker[Session] | None = None


# ---------------------------------------------------------------------
# Async engine + session factory (for FastAPI routes/services)
# ---------------------------------------------------------------------
def get_async_engine_Old() -> AsyncEngine:
    """
    Create (once) and return the async SQLAlchemy engine from settings.DATABASE_URL.
    Connection defaults are attached to the **underlying sync engine**.
    """
    global _async_engine
    if _async_engine is None:
        _async_engine = create_async_engine(
            settings.DATABASE_URL,
            echo=getattr(settings, "DB_ECHO", False),
            pool_pre_ping=True,
        )

        # Attach a **synchronous** listener to the underlying sync engine.
        # (AsyncEngine itself does not support event listeners.)
        def _on_connect(dbapi_connection, connection_record):
            # Optional: set statement_timeout if provided (milliseconds)
            timeout = getattr(settings, "DB_STATEMENT_TIMEOUT_MS", None)
            if timeout:
                with dbapi_connection.cursor() as cur:
                    cur.execute(f"SET statement_timeout = {int(timeout)}")
            # NOTE: Do NOT set tenant GUC here. RLS tenant is set per-request
            # via `SET LOCAL` in src.shared.security.get_principal().

        event.listen(_async_engine, "connect", _on_connect)

    return _async_engine


def get_async_session_factory() -> async_sessionmaker[AsyncSession]:
    """Create (once) and return the async session factory."""
    global _async_session_factory
    if _async_session_factory is None:
        _async_session_factory = async_sessionmaker(
            bind=get_async_engine(),
            expire_on_commit=False,
            class_=AsyncSession,
        )
    return _async_session_factory

# Legacy alias (some modules may call this name)
def async_session_factory() -> async_sessionmaker[AsyncSession]:
    return get_async_session_factory()


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency:
        async def endpoint(session: AsyncSession = Depends(get_session)): ...
    """
    factory = get_async_session_factory()
    async with factory() as session:
        yield session


# ---------------------------------------------------------------------
# Sync engine + session factory (for scripts, migrations, admin tasks)
# ---------------------------------------------------------------------
def get_sync_engine() -> Engine:
    """
    Expose a synchronous Engine. We return the underlying sync_engine of the
    AsyncEngine so the DSN stays centralized.
    If later you want a separate sync DSN/driver, add DATABASE_URL_SYNC and
    create a dedicated sync engine here.
    """
    return get_async_engine().sync_engine


def get_sync_session_factory() -> sessionmaker[Session]:
    """Create (once) and return the sync session factory."""
    global _sync_session_factory
    if _sync_session_factory is None:
        _sync_session_factory = sessionmaker(
            bind=get_sync_engine(),
            autocommit=False,
            autoflush=False,
            expire_on_commit=False,
        )
    return _sync_session_factory


@contextmanager
def get_db_sync() -> Generator[Session, None, None]:
    """
    Usage (scripts/admin):
        from sqlalchemy import text
        from src.shared.database import get_db_sync

        with get_db_sync() as db:
            db.execute(text("SELECT 1"))
            db.commit()
    """
    sfactory = get_sync_session_factory()
    with sfactory() as session:
        yield session

def get_async_engine() -> AsyncEngine:
    """Create (once) and return the async SQLAlchemy engine."""
    global _async_engine
    if _async_engine is None:
        _async_engine = create_async_engine(
            settings.DATABASE_URL,  # from env
            echo=getattr(settings, "DB_ECHO", False),
            pool_pre_ping=True,
        )
    return _async_engine

# --- keep all your existing code above unchanged ---

__all__ = [
    # async
    "get_async_engine",
    "get_async_session_factory",
    "async_session_factory",
    "get_session",
    # sync
    "get_sync_engine",
    "get_sync_session_factory",
    "get_db_sync",
    # orm base
    "Base",
]
